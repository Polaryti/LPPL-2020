// Ejemplo con errores lexicos: 1 error
int main ( )
{
  int  aAa123_2016;
  int c#;                         // caracter desconocido

  aAa123_2016 = 3;
  c = (((aAa123_2016 / 2) + 3.56) - .34) * 2.;
  
  return 0;
}
