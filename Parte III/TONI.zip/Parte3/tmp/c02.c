// Ejemplo de uso de operadores de incremento.
// Debe devolver: 2, 3, 4, 4, 11, 11, 7, 28, 7, 28, 28 
{ int a=2; int b = 7;

  print(a++); print(a); print(++a); print(a);

  print(b+=a); print(b); print(b-=a); print(b*=a); print(b/=a);
  print(a=28); print(a); 
} 
