// Ejemplo sencillo del uso de operadores aritmeticos.
// Debe devolver el mismo numero elevado al cuadrado
{ int a;

  read(a); 
  print ( a *= (((a + a) * (5 % 3)) / 2) - a );
}
